Mi Tienda de compra
===============================

Estructura:
- index.html
- style.css
- app.js
- Mi Tienda de compra.sql
- api/ (archivos PHP)
- uploads/ (carpeta para imágenes)

