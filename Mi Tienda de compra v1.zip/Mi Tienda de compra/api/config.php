<?php

session_start();

$DB_HOST = '127.0.0.1';
$DB_NAME = 'tienda_demo';
$DB_USER = 'root';
$DB_PASS = ''; 

$options = [
  PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
];

try {
  $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, $options);
} catch (Exception $e) {
  http_response_code(500);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['success'=>false, 'message'=>'DB connection error: '.$e->getMessage()]);
  exit;
}

function jsonOut($data){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($data); exit; }
