<?php
require 'config.php';
$input = json_decode(file_get_contents('php://input'), true);
$email = $input['email'] ?? '';
$pass = $input['password'] ?? '';

$stmt = $pdo->prepare("SELECT id, email, password, nombre, role_id FROM usuarios WHERE email = ?");
$stmt_execute = $stmt->execute([$email]);
$user = $stmt->fetch();
if(!$user) jsonOut(['success'=>false, 'message'=>'Credenciales incorrectas']);
if(!password_verify($pass, $user['password'])) jsonOut(['success'=>false, 'message'=>'Credenciales incorrectas']);

$_SESSION['user'] = ['id'=>$user['id'], 'email'=>$user['email'], 'nombre'=>$user['nombre'], 'role_id'=>$user['role_id']];
jsonOut(['success'=>true, 'user'=>$_SESSION['user']]);
