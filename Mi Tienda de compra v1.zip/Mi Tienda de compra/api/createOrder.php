<?php
require 'config.php';
$user = $_SESSION['user'] ?? null;
if(!$user) jsonOut(['success'=>false, 'message'=>'Auth required']);

$input = json_decode(file_get_contents('php://input'), true);
$cart = $input['cart'] ?? [];
if(empty($cart)) jsonOut(['success'=>false, 'message'=>'Carrito vacío']);

$pdo->beginTransaction();
try {
  $total = 0;
  foreach($cart as $productId => $qty){
    $stmt = $pdo->prepare("SELECT precio, stock FROM productos WHERE id = ?");
    $stmt->execute([$productId]);
    $p = $stmt->fetch();
    if(!$p) throw new Exception("Producto $productId no existe");
    if($p['stock'] < $qty) throw new Exception("Stock insuficiente para producto $productId");
    $total += $p['precio'] * $qty;
  }

  $stmt = $pdo->prepare("INSERT INTO pedidos (usuario_id, total, estado) VALUES (?,?,?)");
  $stmt->execute([$user['id'], $total, 'Confirmado']);
  $orderId = $pdo->lastInsertId();

  foreach($cart as $productId => $qty){
    $stmt = $pdo->prepare("SELECT precio, stock FROM productos WHERE id = ?");
    $stmt->execute([$productId]);
    $p = $stmt->fetch();
    $stmt2 = $pdo->prepare("INSERT INTO detalle_pedido (pedido_id, producto_id, cantidad, precio_unit) VALUES (?,?,?,?)");
    $stmt2->execute([$orderId, $productId, $qty, $p['precio']]);
    $stmt3 = $pdo->prepare("UPDATE productos SET stock = stock - ?, vendidos = vendidos + ? WHERE id = ?");
    $stmt3->execute([$qty, $qty, $productId]);
  }

  $pdo->commit();
  jsonOut(['success'=>true, 'orderId'=>$orderId]);
} catch(Exception $e){
  $pdo->rollBack();
  jsonOut(['success'=>false, 'message'=>$e->getMessage()]);
}
