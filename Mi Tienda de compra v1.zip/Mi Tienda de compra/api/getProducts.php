<?php
require 'config.php';
$q = $_GET['query'] ?? '';
$sort = $_GET['sort'] ?? 'default';

$sql = "SELECT id, nombre, descripcion, precio, stock, imagen, categoria, vendidos FROM productos WHERE 1 ";
$params = [];

if($q !== ''){
  $sql .= " AND (nombre LIKE :q OR descripcion LIKE :q OR categoria LIKE :q) ";
  $params[':q'] = "%$q%";
}

if($sort === 'price_asc') $sql .= " ORDER BY precio ASC ";
elseif($sort === 'price_desc') $sql .= " ORDER BY precio DESC ";
elseif($sort === 'name') $sql .= " ORDER BY nombre ASC ";
else $sql .= " ORDER BY id ASC ";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

jsonOut(['success'=>true, 'products'=>$rows]);
